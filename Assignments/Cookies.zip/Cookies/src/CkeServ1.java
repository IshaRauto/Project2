

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CkeServ1
 */
@WebServlet("/CkeServ1")
public class CkeServ1 extends HttpServlet {
   

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			response.setContentType("text/html");
			PrintWriter out=response.getWriter();
			
			String n=request.getParameter("userName");
			out.print("Welcome"+n);
			
			Cookie ck=new Cookie("uname",n);
			response.addCookie(ck);
			
			out.print("<form action='Cke2'>");
		    out.print("<input type='submit' value='go'");
		    out.print("</form>");
		    out.close();
		} catch(Exception e) {
			System.out.println(e);
		}
		doGet(request, response);
	}

}
