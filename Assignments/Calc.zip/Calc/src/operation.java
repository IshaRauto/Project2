

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class operation
 */
@WebServlet("/operation")
public class operation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int numb1=Integer.parseInt(request.getParameter("num1"));
		int numb2=Integer.parseInt(request.getParameter("num2"));
		HttpSession session=request.getSession();
		 session.setAttribute("num1",numb1);
		 session.setAttribute("num2",numb2);
		String op=request.getParameter("operation");
		if(op.equals("add")) {
			request.getRequestDispatcher("Add").forward(request, response);
		}
		else if(op.equals("sub")) 
			request.getRequestDispatcher("Sub").forward(request, response);
		else if(op.equals("div")) 
			request.getRequestDispatcher("Div").forward(request, response);
		else if(op.equals("mul")) 
			request.getRequestDispatcher("Multiply").forward(request, response);		
		}
		
	}

	

	
	

