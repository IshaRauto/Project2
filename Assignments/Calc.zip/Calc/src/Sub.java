

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/Sub")
public class Sub extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		int num1=(int) session.getAttribute("num1");
		int num2=(int)session.getAttribute("num2");
       int res=num1-num2;
       System.out.println(res);
       request.setAttribute("result", res);
       request.getRequestDispatcher("result.jsp").forward(request, response);
	}

}
